package com.rackspace.onlinecodingtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineCodingTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineCodingTestApplication.class, args);
	}

}
